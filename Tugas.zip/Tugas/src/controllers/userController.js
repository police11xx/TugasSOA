const { QueryTypes } = require('sequelize')
const w2Database = require('../databases/w2Connection')

const addUser = async (req, res) =>{
    let {username, password, nama, alamat, nomorhp} = req.body
    let [result, metadata] = await w2Database.query(
        `insert into user (username, password, nama, alamat, nomorhp) values(:username, :password, :nama, :alamat, :nomorhp)`,
        {
            replacements: {
                username: username,
                password: password, 
                nama: nama,
                alamat: alamat,
                nomorhp: nomorhp
            }
        }
    )
    return res.status(201).send({
        'message': 'User successfully registered',
        'username': username,
        'password': password,
        'nama': nama,
        'alamat': alamat,
        'nomorhp': nomorhp,
    })
}



const loginUser = async (req,res) => {
    let {username,password} = req.body
        let keyword = `%${username}%`
        let keyword2 = `%${password}%`
        let [users, metadata] = await w2Database.query(
            `select * from user where username like ? AND password like ?`,
            {
                replacements: [keyword,keyword2]
            }
        )
        return res.status(200).send(users)
    
}

const editUser = async (req,res) => {
    let {username} = req.params
    let { nama, alamat, nomorhp, oldpassword,newpassword} = req.body

    if(await !userExist(username))
        return res.status(404).send({
            'message': 'User not found!'
        })

    let [result, metadata] = await w2Database.query(
        `update user set password = :password, nama = :nama, alamat = :alamat, nomorhp = :nomorhp where username = :username`,
        {
            replacements:{
                username: username,
                password: newpassword,
                nama: nama,
                alamat: alamat,
                nomorhp : nomorhp
            }
        }
    )
    let updatedUser = await selectUserByID(username)
    console.log(updatedUser)
    return res.status(200).send({
        'message': 'User successfully updated',
        'password': updatedUser.password,
        'nama': updatedUser.nama,
        'alamat': updatedUser.alamat,
        'nomorhp': updatedUser.nomorhp
       
    })
}
module.exports = {
    addUser, loginUser, editUser
}


async function userExist(username){
    let select = await selectUserByID(username)
    return select.length > 0
}


async function selectUserByID(username){
    let [user, metadata] = await w2Database.query(
        `select * from user where username = :username`,
        {
            replacements:{
                username: username
            }
        }
    )
    return user[0]
}

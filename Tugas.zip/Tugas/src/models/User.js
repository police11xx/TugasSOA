
'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    static associate(models) {}
  }
  User.init(
    {
        username: {
            type: DataTypes.STRING,
            primaryKey: true,
            unique: true,
            allowNull: false
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        nama: {
            type: DataTypes.STRING,
            allowNull: false
        },
        alamat: {
          type: DataTypes.STRING,
          allowNull: false
      },
      nomorhp: {
        type: DataTypes.BIGINT,
        allowNull: false
    }
    },
    {
      sequelize,
      modelName: 'User',
      tableName: 'user'
    }
  );
  return Buku;
};



const express = require('express')
const router = express.Router()


const {
    addUser, 
    loginUser,
    editUser
} = require('../controllers/userController')

router.post('/user', addUser)
router.post('/login', loginUser)
router.put('/user/:username', editUser)


//Jangan lupa export
module.exports = router